# BANK-MANAGEMENT-SYSTEM
A simple java project on basic bank transactions!
LANGUAGE:JAVA
IDE:ECLIPSE
